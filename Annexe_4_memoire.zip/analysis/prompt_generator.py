

ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

PREFIX = '''You are an expert in sentiment analysis, specializing in understanding user reviews and evaluating how likely a reviewer is to recommend a product. Your task is to analyze user-generated reviews in JSON format, combined with a detailed product description, and provide a numerical score from 0 to 10 for each review. This score represents how likely the reviewer is to recommend the product, where 0 indicates "not likely at all" and 10 indicates "extremely likely."

Instructions:
- Consider the product description as context to understand what aspects of the product are positive or negative.
- Analyze each review carefully, taking into account the text content and all available metadata (e.g., star rating, purchase type, and other fields).
- For each review, provide a single integer value between 0 and 10 that reflects how likely the reviewer is to recommend the product based on the tone, sentiment, and metadata.
- If the sentiment is ambiguous, rely on the metadata (e.g., a verified purchase and a high star rating suggest a higher likelihood to recommend).

Output Format:
- For each review, simply write its letter followed by the recommendation likelihood score between 0 and 10

Product Description:
%s

Reviews:
'''

PRODUCT_DESCRIPTIONS = {
    'mattress': '''Novilla Queen Mattress (Memory Foam Mattress, Medium Firm, Queen 12 Inch, $256)
The mattress queen is compressed, rolled, and shipped in a box, making it convenient to set up. For a better sleeping experience, please allow at least 72 hours for the mattress to fully expand.''',
    'no_mans_sky': '''No Man's Sky (Video game, Hello Games, released in August 2016)
Science-Fiction, Space Exploration, Near-infinite procedurally generated universe, Criticized at launch but received multiple free updates''',
    'petit_jardin': '''Le Petit Jardin, a Michelin-starred traditional fine dining restaurant in the center of Montpellier, offers a sophisticated menu that focuses on fresh, seasonal ingredients sourced from local producers.
As its name suggests, this restaurant has one of the prettiest terraces in the city, nestled in a lush, quiet garden.
The menu changes frequently to highlight the best of the season, with an impressive selection of regional wines.''',
    'shampoo_men': '''Shampoo for men (volume: 1L)''',
    'shampoo_women_1l': '''Shampoo for women (volume: 1L)''',
    'shampoo_women_5l': '''Shampoo for women (volume: 5L)''',
    'victor_ferry': '''Book titled "12 Rhetorical Lessons to Seize Power: Turn Your Ideas into Speeches and Move Your Audience".
The author is a French Youtuber who focuses on making his audience progress in rhetoric.'''
}


def generate_prompt(product, reviews):
    letters = [ALPHABET[i] for i in range(len(reviews))]
    prompt = PREFIX % PRODUCT_DESCRIPTIONS[product]
    for review, letter in zip(reviews, letters):
        prompt += f'- Review {letter}:\n'
        prompt += str(review) + '\n\n'
    return prompt, letters

