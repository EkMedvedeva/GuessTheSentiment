import json
from formatter import format_review
from models import *


def translate_review(review, metadata, translation):
    review = review.copy()
    review.update(metadata[translation])
    return review


with open('../inputs/reviews.json', 'r') as file:
    reviews = json.loads(file.read())

with open('../inputs/metadata.json', 'r') as file:
    reviews_metadata = json.loads(file.read())
    for product in reviews_metadata:
        reviews_metadata[product] = {int(key): value for key, value in reviews_metadata[product].items()}


def analyze_reviews(model):
    result = {}
    for product in reviews:
        result[product] = {}
        formatted_reviews = []

        review_positions = list(reviews_metadata[product])
        
        for review_position in review_positions:
            review = reviews[product][review_position]
            if model.format:
                metadata = reviews_metadata[product][review_position]
                language = metadata['language']
                if language != 'english' and model.translation != 'original':
                    review = translate_review(review, metadata, model.translation)
                    language = 'english'
                review = format_review(review, language, model.context)
            formatted_reviews.append(review)
        
        outputs = model.analyze_reviews(product, formatted_reviews)

        for review_position, output in zip(review_positions, outputs):
            result[product][review_position] = output
        
    return result


model = BertMultilingual('original', 'context')
#model = LargeLanguageModel('gpt4')
result = analyze_reviews(model)
with open(f'../results/{model.name}.json', 'w') as file:
    file.write(json.dumps(result, indent=4))


