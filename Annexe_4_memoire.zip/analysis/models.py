print('Importing transformers models...')
from transformers import (
    BertForSequenceClassification, BertTokenizer,
    AutoModelForSequenceClassification, AutoTokenizer
)
print('Done')
import textblob
from textblob_fr import PatternTagger, PatternAnalyzer
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import numpy as np
from prompt_generator import generate_prompt
import pyperclip


class BertMultilingual:

    def __init__(self, translation, context):
        self.format = True
        self.translation = translation
        self.context = context
        self.name = f'BertMultilingual_{translation}_{context}'
        self.model_name = 'nlptown/bert-base-multilingual-uncased-sentiment'
        self.tokenizer = BertTokenizer.from_pretrained(self.model_name)
        self.model = BertForSequenceClassification.from_pretrained(self.model_name)

    def analyze_reviews(self, product, reviews):
        outputs = []
        for review in reviews:
            encoded_input = self.tokenizer(review, return_tensors='pt')
            output = self.model(**encoded_input)
            output = output.logits.detach().numpy()[0].tolist()
            outputs.append(output)
        return outputs


class RobertaMultilingual:

    def __init__(self, translation, context):
        self.format = True
        self.translation = translation
        self.context = context
        self.name = f'RobertaMultilingual_{translation}_{context}'
        self.model_name = 'clapAI/roberta-large-multilingual-sentiment'
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(self.model_name)

    def analyze_reviews(self, product, reviews):
        outputs = []
        for review in reviews:
            encoded_input = self.tokenizer(review, return_tensors='pt')
            output = self.model(**encoded_input)
            output = output.logits.detach().numpy()[0].tolist()
            outputs.append(output)
        return outputs


class RobertaLatest:

    def __init__(self, translation, context):
        self.format = True
        self.translation = translation
        self.context = context
        self.name = f'RobertaLatest_{translation}_{context}'
        self.model_name = 'cardiffnlp/twitter-roberta-base-sentiment-latest'
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(self.model_name)

    def analyze_reviews(self, product, reviews):
        outputs = []
        for review in reviews:
            encoded_input = self.tokenizer(review, return_tensors='pt')
            output = self.model(**encoded_input)
            output = output.logits.detach().numpy()[0].tolist()
            outputs.append(output)
        return outputs


class TextBlob:

    def __init__(self, translation, context):
        self.format = True
        self.translation = translation
        self.context = context
        self.name = f'TextBlob_{translation}_{context}'

    def analyze_reviews(self, product, reviews):
        outputs = []
        for review in reviews:
            blob = textblob.TextBlob(review)
            output = [blob.sentiment.polarity, blob.sentiment.subjectivity]
            outputs.append(output)
        return outputs


class TextBlobFr:

    def __init__(self, translation, context):
        self.format = True
        self.translation = translation
        self.context = context
        self.name = f'TextBlobFr_{translation}_{context}'

    def analyze_reviews(self, product, reviews):
        outputs = []
        for review in reviews:
            blob = textblob.TextBlob(review, pos_tagger=PatternTagger(), analyzer=PatternAnalyzer())
            output = list(blob.sentiment)
            outputs.append(output)
        return outputs


class Vader:

    def __init__(self, translation, context):
        self.format = True
        self.translation = translation
        self.context = context
        self.name = f'Vader_{translation}_{context}'
        self.analyzer = SentimentIntensityAnalyzer()

    def analyze_reviews(self, product, reviews):
        outputs = []
        for review in reviews:
            output = self.analyzer.polarity_scores(review)
            output = [scores['neg'], scores['neu'], scores['pos'], scores['compound']]
            outputs.append(output)
        return outputs


class VaderMulti:

    def __init__(self, translation, context):
        self.format = True
        self.translation = translation
        self.context = context
        self.name = f'VaderMulti_{translation}_{context}'
        self.analyzer = SentimentIntensityAnalyzer()

    def analyze_reviews(self, product, reviews):
        outputs = []
        for review in reviews:
            output = self.analyzer.polarity_scores(review)
            output = [scores['neg'], scores['neu'], scores['pos'], scores['compound']]
            outputs.append(output)
        return outputs


class LargeLanguageModel:

    def __init__(self, name):
        self.format = False
        self.name = f'{name}_original_context'
        self.analyzer = SentimentIntensityAnalyzer()

    def analyze_reviews(self, product, reviews):
        outputs = []
        for i in range(0, len(reviews), 20):
            prompt, letters = generate_prompt(product, reviews)
            
            pyperclip.copy(prompt)
            print('Le prompt a été copié dans le presse-papiers')

            for letter in letters:
                output = int(input(f'{letter}: ? '))
                outputs.append(output)
        
        return outputs

