import json
import numpy as np
from scipy.optimize import dual_annealing
import os
import time
import jsbeautifier
import re


with open('../inputs/guesses.json', 'r') as file:
    guesses = json.loads(file.read())


def get_ratings_distribution(ratings, return_middle=False):
    counts = np.zeros(11, dtype=int)
    unique, unique_counts = np.unique(ratings, return_counts=True)
    counts[unique] = unique_counts
    sum_counts = np.cumsum(counts)
    n = sum_counts[-1]
    lower_ranks = (sum_counts - counts) / (n - 1)
    upper_ranks = (sum_counts - 1) / (n - 1)
    if return_middle:
        middle_ranks = (lower_ranks + upper_ranks) / 2
        return middle_ranks
    return lower_ranks, upper_ranks


def convert_ratings_to_ranks(ratings, distribution=None, return_middle=False):
    if distribution is None:
        distribution = get_ratings_distribution(ratings, return_middle=return_middle)
    if return_middle:
        middle_ranks = distribution
        return middle_ranks[ratings]
    lower_ranks, upper_ranks = distribution
    return lower_ranks[ratings], upper_ranks[ratings]


def load_guesses(set_count):
    ratings = []
    weights = []
    
    set_ids = []
    review_ids = []
    rating_counts = []
    
    review_id = 0
    for product in guesses:
        review_count = len(guesses[product])
        review_set_ids = np.tile(np.arange(set_count), 1 + review_count // set_count)
        np.random.shuffle(review_set_ids)
        review_set_ids = review_set_ids[:review_count]
        
        for review_position, review_set_id in zip(guesses[product], review_set_ids):

            set_ids.append(review_set_id)
            review_ids.append(review_id)
            
            rating_count = len(guesses[product][review_position])
            rating_counts.append(rating_count)
            for rating in guesses[product][review_position]:
                ratings.append(rating)
                weights.append(1/rating_count)
                
            review_id += 1
    
    ratings = np.array(ratings)
    weights = np.array(weights)
    set_ids = np.array(set_ids)
    review_ids = np.array(review_ids)
    rating_counts = np.array(rating_counts)

    return ratings, weights, set_ids, review_ids, rating_counts


def load_outputs(model):
    with open(f'../results/{model}', 'r') as file:
        data = json.loads(file.read())
    
    outputs = []
    
    for product in guesses:
        for review_position in guesses[product]:
            outputs.append(data[product][review_position])
    
    outputs = np.array(outputs)
    return outputs


def calculate_error_from_ranks(ranks, weights, lower_ranks, upper_ranks):
    error = np.dot((np.power(upper_ranks-ranks, 3) - np.power(lower_ranks-ranks, 3)) / (3*(upper_ranks-lower_ranks)), weights) / np.sum(weights)
    return error


def calculate_error(outputs, weights, lower_ranks, upper_ranks, rating_counts, params):
    n = len(outputs)
    scores = np.dot(outputs, params)
    ranks = np.argsort(np.argsort(scores)) / (n - 1)
    ranks = np.repeat(ranks, rating_counts)
    error = calculate_error_from_ranks(ranks, weights, lower_ranks, upper_ranks)
    return error


def optimize_params(outputs, weights, lower_ranks, upper_ranks, rating_counts, add_mean=False):

    if add_mean:
        mean = np.mean(outputs, axis=1, keepdims=True)
        outputs = np.concatenate((outputs, mean), axis=1)
    
    param_count = len(outputs[0])
    best_params = None
    min_error = None
    
    def objective(params):
        error = calculate_error(outputs, weights, lower_ranks, upper_ranks, rating_counts, params)

        nonlocal min_error, best_params
        
        if min_error is None or error < min_error:
            min_error = error
            best_params = params
        
        return error
    
    bounds = [(-10000, 10000) for _ in range(param_count)]
    result = dual_annealing(objective, bounds=bounds)
    
    scores = np.dot(outputs, best_params)
    quantiles = np.linspace(0, 1, num=101)
    score_quantiles = np.quantile(scores, quantiles)
    
    return (best_params, score_quantiles)


set_count = 5
ratings, weights, set_ids, review_ids, rating_counts = load_guesses(set_count)
lower_ranks, upper_ranks = convert_ratings_to_ranks(ratings)

training_result = {
    'set_ids': set_ids.tolist(),
    'params': {}
}

for model in os.listdir('../results'):
    
    kwargs = {}
    for key in ('BertMultilingual', 'RobertaLatest', 'RobertaMultilingual'):
        if key in model:
            kwargs['add_mean'] = True
    
    outputs = load_outputs(model)
    training_result['params'][model] = {}
    
    for set_id in range(set_count):
        train_mask = set_ids != set_id
        input_train_mask = np.repeat(train_mask, rating_counts)
        
        train_outputs = outputs[train_mask]
        train_weights = weights[input_train_mask]
        train_lower_ranks = lower_ranks[input_train_mask]
        train_upper_ranks = upper_ranks[input_train_mask]
        train_rating_counts = rating_counts[train_mask]

        if outputs.ndim == 2:
            trained_params = optimize_params(train_outputs, train_weights, train_lower_ranks, train_upper_ranks, train_rating_counts, **kwargs)
        else:
            trained_params = (get_ratings_distribution(train_outputs, return_middle=True),)

        training_result['params'][model][set_id] = [params.tolist() for params in trained_params]

    print(model)


result_file_name = f'training_{int(time.time())}.json'
with open(f'../training_results/{result_file_name}', 'w') as file:
    options = jsbeautifier.default_options()
    options.indent_size = 2
    options.wrap_line_length = 100
    text = jsbeautifier.beautify(json.dumps(training_result), options)
    pattern = r', -\n(\s*)(\d)'
    replacement = r',\n\1-\2'
    text = re.sub(pattern, replacement, text)
    file.write(text)


