import json
import numpy as np
import matplotlib.pyplot as plt


result_file = '../training_results/training_1743295755.json'


with open('../inputs/guesses.json', 'r') as file:
    guesses = json.loads(file.read())
    
with open('../inputs/metadata.json', 'r') as file:
    reviews_metadata = json.loads(file.read())


##model_whitelist = [
##    'deepseekv3_original_context.json',
##    'gpt4_original_context.json',
##    'grok3_original_context.json',
##    'BertMultilingual_translation1_context.json',
##    'BertMultilingual_original_context.json',
##    'RobertaMultilingual_original_nocontext.json',
##    'RobertaMultilingual_translation1_nocontext.json',
##    'RobertaLatest_translation2_nocontext.json',
##    'Vader_translation1_context.json',
##    'VaderMulti_original_context.json',
##    'VaderMulti_translation1_context.json',
##    'RobertaLatest_original_nocontext.json',
##    'Vader_original_context.json',
##    'TextBlob_translation1_context.json',
##    'TextBlob_original_context.json'
##]
##model_whitelist = [
##    'BertMultilingual_translation2_nocontext.json',
##    'deepseekv3_original_context.json',
##    'gpt4_original_context.json',
##    'grok3_original_context.json',
##    'RobertaLatest_translation2_nocontext.json',
##    'RobertaMultilingual_translation2_nocontext.json',
##    'TextBlob_translation2_nocontext.json',
##    'VaderMulti_translation2_nocontext.json',
##    'Vader_translation2_nocontext.json',
##]
model_whitelist = [
    'deepseekv3_original_context.json',
    'gpt4_original_context.json',
    'grok3_original_context.json',
    'RobertaMultilingual_original_context.json',
    'RobertaMultilingual_original_nocontext.json',
    'RobertaMultilingual_translation1_context.json',
    'RobertaMultilingual_translation1_nocontext.json',
    'RobertaMultilingual_translation2_context.json',
    'RobertaMultilingual_translation2_nocontext.json',
]


def load_guesses():
    ratings = []
    weights = []
    
    product_ids = []
    language_ids = []
    review_ids = []
    rating_counts = []
    
    product_mask_ids = {
        'mattress': 0,
        'no_mans_sky': 1,
        'petit_jardin': 2,
        'shampoo': 3,
        'victor_ferry': 4
    }
    product_count = 5

    language_map = {
        'english': 0,
        'french': 1,
        'russian': 2
    }

    review_id = 0
    for product in guesses:
        
        for product_mask in product_mask_ids:
            if product.startswith(product_mask):
                product_mask_id = product_mask_ids[product_mask]

        review_count = len(guesses[product])
        
        for review_position in guesses[product]:
            product_ids.append(product_mask_id)
            language_ids.append(language_map[reviews_metadata[product][review_position]['language']])
            review_ids.append(review_id)

            rating_count = len(guesses[product][review_position])
            rating_counts.append(rating_count)
            for rating in guesses[product][review_position]:
                ratings.append(rating)
                weights.append(1/rating_count)
                
            review_id += 1
    
    ratings = np.array(ratings)
    weights = np.array(weights)
    product_ids = np.array(product_ids)
    language_ids = np.array(language_ids)
    review_ids = np.array(review_ids)
    rating_counts = np.array(rating_counts)

    return ratings, weights, product_ids, language_ids, review_ids, rating_counts


def load_outputs(model):
    with open(f'../results/{model}', 'r') as file:
        data = json.loads(file.read())
    
    outputs = []

    for product in guesses:
        for review_position in guesses[product]:
            outputs.append(data[product][review_position])
    
    outputs = np.array(outputs)
    return outputs


def load_trained_params():

    trained_params = {}
    
    with open(result_file, 'r') as file:
        data = json.loads(file.read())
    
    set_ids = np.array(data['set_ids'], dtype=int)
    set_count = np.max(set_ids) + 1
    
    for model in data['params']:

        if model not in model_whitelist:
            continue
        
        trained_params[model] = {}
        
        for set_id in range(set_count):
            trained_params[model][set_id] = tuple(
                np.array(array)
                for array in data['params'][model][str(set_id)]
            )
        
    return set_ids, trained_params


def get_ratings_distribution(ratings, return_middle=False):
    counts = np.zeros(11, dtype=int)
    unique, unique_counts = np.unique(ratings, return_counts=True)
    counts[unique] = unique_counts
    sum_counts = np.cumsum(counts)
    n = sum_counts[-1]
    lower_ranks = (sum_counts - counts) / (n - 1)
    upper_ranks = (sum_counts - 1) / (n - 1)
    if return_middle:
        middle_ranks = (lower_ranks + upper_ranks) / 2
        return middle_ranks
    return lower_ranks, upper_ranks


def convert_ratings_to_ranks(ratings, distribution=None, return_middle=False):
    if distribution is None:
        distribution = get_ratings_distribution(ratings, return_middle=return_middle)
    if return_middle:
        middle_ranks = distribution
        return middle_ranks[ratings]
    lower_ranks, upper_ranks = distribution
    return lower_ranks[ratings], upper_ranks[ratings]


def calculate_error_from_ranks(ranks, weights, lower_ranks, upper_ranks):
    error = (np.power(upper_ranks-ranks, 3) - np.power(lower_ranks-ranks, 3)) / (3*(upper_ranks-lower_ranks))
    return error


def calculate_test_error(outputs, weights, lower_ranks, upper_ranks, rating_counts, trained_params, add_mean=False):
    if outputs.ndim == 2:
        params, score_quantiles = trained_params
        quantiles = np.linspace(0, 1, num=101)
        if add_mean:
            mean = np.mean(outputs, axis=1, keepdims=True)
            outputs = np.concatenate((outputs, mean), axis=1)
        scores = np.dot(outputs, params)
        ranks = np.interp(scores, score_quantiles, quantiles)
    else:
        distribution, = trained_params
        ranks = convert_ratings_to_ranks(outputs, distribution=distribution, return_middle=True)
    return ranks, calculate_error_from_ranks(np.repeat(ranks, rating_counts), weights, lower_ranks, upper_ranks)


def check_llm(model):
    for key in ('gpt4', 'grok3', 'deepseekv3'):
        if key in model:
            return True
    return False


ratings, weights, product_ids, language_ids, review_ids, rating_counts = load_guesses()
ratings_distribution = get_ratings_distribution(ratings)
lower_ranks, upper_ranks = convert_ratings_to_ranks(ratings)
set_ids, trained_params = load_trained_params()
set_count = np.max(set_ids) + 1

errors = {}
review_ranks = np.zeros((np.max(review_ids)+1, len(trained_params)), dtype=float)

for model_index, model in enumerate(trained_params):
    
    kwargs = {}
    for key in ('BertMultilingual', 'RobertaLatest', 'RobertaMultilingual'):
        if key in model:
            kwargs['add_mean'] = True

    nps_scores = {
        'product0': [],
        'product1': [],
        'product2': [],
        'product3': [],
        'product4': []
    }
    
    errors[model] = {
        'global': [],
        'product0': [],
        'product1': [],
        'product2': [],
        'product3': [],
        'product4': [],
        'language0': [],
        'language1': [],
        'language2': []
    }
    outputs = load_outputs(model)
    
    for set_id in trained_params[model]:
        test_mask = set_ids == set_id
        input_test_mask = np.repeat(test_mask, rating_counts)
        
        test_outputs = outputs[test_mask]
        test_weights = weights[input_test_mask]
        test_lower_ranks = lower_ranks[input_test_mask]
        test_upper_ranks = upper_ranks[input_test_mask]
        test_product_ids = product_ids[test_mask]
        test_language_ids = language_ids[test_mask]
        test_review_ids = review_ids[test_mask]
        test_rating_counts = rating_counts[test_mask]
        
        params = trained_params[model][set_id]
        ranks, error = calculate_test_error(
            test_outputs, test_weights,
            test_lower_ranks, test_upper_ranks, test_rating_counts,
            params, **kwargs
        )

        e = np.dot(error, test_weights) / np.sum(test_weights)
        errors[model]['global'].append(e)
        
        for product_id in range(5):
            mask = test_product_ids == product_id
            promoters_mask = ranks[mask] >= ratings_distribution[0][9]
            detractors_mask = ranks[mask] <= ratings_distribution[1][6]
            nps_scores[f'product{product_id}'].append(100*(np.sum(promoters_mask)-np.sum(detractors_mask)) / np.sum(mask))
            
            mask = np.repeat(mask, test_rating_counts)
            e = np.dot(error[mask], test_weights[mask]) / np.sum(test_weights[mask])
            errors[model][f'product{product_id}'].append(e)

        for language_id in range(3):
            mask = test_language_ids == language_id
            mask = np.repeat(mask, test_rating_counts)
            e = np.dot(error[mask], test_weights[mask]) / np.sum(test_weights[mask])
            errors[model][f'language{language_id}'].append(e)

        for review_id in np.unique(test_review_ids):
            mask = test_review_ids == review_id
            if np.any(mask):
                review_ranks[review_id, model_index] = ranks[mask][0]

##    row = [model]
##    for key in nps_scores:
##        #print(model, key, np.array(nps_scores[key]))
##        row.append(f'{np.mean(nps_scores[key]):.6f}')
##        row.append(f'{np.std(nps_scores[key]):.6f}')
##    print('\t'.join(row))
##        

    row = [model]
    for key in errors[model]:
        error = errors[model][key]
        if len(error) == 0:
            print(key)
            continue
        row.append(f'{np.mean(error):.6f}')
        row.append(f'{np.std(error):.6f}')
    print('\t'.join(row))

##review_ranks_std = np.std(review_ranks, axis=1)
##argsort = np.argsort(review_ranks_std)
##for i in range(10):
##    review_id = argsort[i]
##    print(i, review_id, review_ranks_std[review_id])
##for i in range(len(argsort)-10, len(argsort)):
##    review_id = argsort[i]
##    print(i, review_id, review_ranks_std[review_id])

